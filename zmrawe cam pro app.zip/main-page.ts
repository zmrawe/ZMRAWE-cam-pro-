import { EventData, Observable } from '@nativescript/core';
import { Page, Image, Slider } from '@nativescript/core';
import * as camera from '@nativescript/camera';
import * as imageSource from '@nativescript/core/image-source';
import * as fs from '@nativescript/core/file-system';

class ZmraweViewModel extends Observable {
  zoomLabel = '1x';
    recordLabel = '🎥 تسجيل';
      galleryVisible = 'collapse';
        images: { src: string }[] = [];
          private isRecording = false;

            constructor() {
                super();
                    this.set('zoomLabel', this.zoomLabel);
                        this.set('recordLabel', this.recordLabel);
                            this.set('galleryVisible', this.galleryVisible);
                                this.set('images', this.images);
                                  }

                                    onZoomChange(value: number) {
                                        this.zoomLabel = `${Math.round(value)}x`;
                                            this.set('zoomLabel', this.zoomLabel);
                                                // هنا ممكن تضيف منطق زوم رقمي لاحقاً
                                                  }

                                                    async onCapture() {
                                                        try {
                                                              await camera.requestPermissions();
                                                                    const img = await camera.takePicture({ keepAspectRatio: true, width: 1280, height: 720 });
                                                                          const src = imageSource.fromNativeSource(img);
                                                                                const folder = fs.knownFolders.documents().getFolder('zmrawe_images');
                                                                                      const fileName = `ZMRAWE_${Date.now()}.jpg`;
                                                                                            const filePath = fs.path.join(folder.path, fileName);
                                                                                                  src.saveToFile(filePath, 'jpg');
                                                                                                        this.images.unshift({ src: filePath });
                                                                                                              this.set('images', this.images);
                                                                                                                  } catch (e) {
                                                                                                                        console.log('Error capturing image', e);
                                                                                                                            }
                                                                                                                              }

                                                                                                                                onOpenGallery() {
                                                                                                                                    this.galleryVisible = 'visible';
                                                                                                                                        this.set('galleryVisible', this.galleryVisible);
                                                                                                                                          }

                                                                                                                                            onCloseGallery() {
                                                                                                                                                this.galleryVisible = 'collapse';
                                                                                                                                                    this.set('galleryVisible', this.galleryVisible);
                                                                                                                                                      }

                                                                                                                                                        onToggleRecord() {
                                                                                                                                                            // تسجيل فيديو حقيقي في NativeScript يحتاج إعدادات إضافية ومكتبات أخرى
                                                                                                                                                                this.isRecording = !this.isRecording;
                                                                                                                                                                    this.recordLabel = this.isRecording ? '⏹ إيقاف' : '🎥 تسجيل';
                                                                                                                                                                        this.set('recordLabel', this.recordLabel);
                                                                                                                                                                          }
                                                                                                                                                                          }

                                                                                                                                                                          let page: Page;
                                                                                                                                                                          let vm: ZmraweViewModel;

                                                                                                                                                                          export function onNavigatingTo(args: EventData) {
                                                                                                                                                                            page = <Page>args.object;
                                                                                                                                                                              vm = new ZmraweViewModel();
                                                                                                                                                                                page.bindingContext = vm;

                                                                                                                                                                                  const zoomSlider = <Slider>page.getViewById('zoomSlider');
                                                                                                                                                                                    zoomSlider.on('valueChange', (e: any) => {
                                                                                                                                                                                        vm.onZoomChange(e.value);
                                                                                                                                                                                          });
                                                                                                                                                                                          }